# ARSH Android

ARSH saytını tam ekran Android tətbiqi kimi açan layihədir.

Sayt:
https://arsh-site.hashimov994.workers.dev/

Tətbiq adı: ARSH
Package ID: com.arsh.app

## APK/AAB yaratmaq

Android Studio ilə bu qovluğu açın və Gradle sinxronizasiyasının tamamlanmasını gözləyin.

Test APK:
Build > Build APK(s)

Google Play üçün:
Build > Generate Signed Bundle / APK > Android App Bundle

Google Play-ə yükləmək üçün release AAB-ni imzalamaq lazımdır.
